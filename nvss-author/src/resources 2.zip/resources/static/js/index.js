$(function(){
	NS.init();
});